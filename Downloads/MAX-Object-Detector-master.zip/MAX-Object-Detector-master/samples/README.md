# Sample Details

## Images


| image | source | license | 
|---|---|---|
| `dog-human.jpg`  | [Pexels](https://www.pexels.com/photo/animal-big-blur-breed-532310/)  | [CC0 License](https://creativecommons.org/publicdomain/zero/1.0/)  | 
| `jockey.jpg`     | [Pexels](https://www.pexels.com/photo/action-athlete-competition-course-158976/)  |  [CC0 License](https://creativecommons.org/publicdomain/zero/1.0/) | 
| `baby-bear.jpg`  | [Pexels](https://www.pexels.com/photo/wood-bridge-cute-sitting-39369/)  |  [CC0 License](https://creativecommons.org/publicdomain/zero/1.0/) |  
| `a-pen-i-am.jpg` | authors  | [CC0 License](https://creativecommons.org/publicdomain/zero/1.0/)  |  
